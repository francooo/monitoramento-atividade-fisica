import { z } from "zod";

export const signInSchema = z.object({
  email: z.string().trim().min(1, "Informe seu e-mail.").email("E-mail inválido."),
  password: z.string().min(1, "Informe sua senha."),
});

export const signUpSchema = z
  .object({
    name: z.string().trim().min(2, "Informe seu nome completo."),
    email: z.string().trim().min(1, "Informe seu e-mail.").email("E-mail inválido."),
    password: z.string().min(6, "A senha precisa de pelo menos 6 caracteres."),
    confirmPassword: z.string(),
  })
  .refine((v) => v.password === v.confirmPassword, {
    path: ["confirmPassword"],
    message: "As senhas não são iguais.",
  });

export const resetRequestSchema = z.object({
  email: z.string().trim().min(1, "Informe seu e-mail.").email("E-mail inválido."),
});

export const activitySchema = z.object({
  title: z.string().trim().min(2, "Dê um nome ao treino."),
  kind: z.enum(["corrida", "caminhada", "pedal", "trilha"]),
  /** Quilômetros, como a pessoa digita: "8,24" ou "8.24". */
  distanceKm: z.coerce
    .number({ invalid_type_error: "Distância inválida." })
    .positive("A distância precisa ser maior que zero.")
    .max(1000, "Distância acima do limite."),
  durationMinutes: z.coerce
    .number({ invalid_type_error: "Duração inválida." })
    .positive("A duração precisa ser maior que zero.")
    .max(60 * 24, "Duração acima do limite."),
  startedAt: z.coerce.date(),
  city: z.string().trim().max(80).optional().or(z.literal("")),
  notes: z.string().trim().max(500).optional().or(z.literal("")),
});

export type SignInInput = z.infer<typeof signInSchema>;
export type SignUpInput = z.infer<typeof signUpSchema>;
export type ActivityInput = z.infer<typeof activitySchema>;

/** Aceita vírgula decimal do teclado pt-BR antes de validar. */
export function parseDecimal(value: FormDataEntryValue | null): string {
  return String(value ?? "").replace(",", ".");
}
